# OfficeBox for Android

OfficeBox is a lightweight Android office-file reader/editor that uses Android's Storage Access Framework and has no network dependency at runtime.

## Built-in support
- DOCX — read and edit paragraph text, save as a new DOCX while keeping the package/resources; complex formatting may be simplified inside edited paragraphs.
- XLSX — read/edit the first sheet as a tab-separated grid; save values back to the first worksheet. Advanced formulas, merged-cell layout and styles on the edited sheet are not preserved.
- PPTX — read text slide-by-slide and edit existing text runs; save back into the presentation package.
- PDF — page rendering, add a text note on a page, save an edited rasterized PDF copy.
- ODT / ODS / ODP — read and basic edit of textual content.
- RTF / TXT / CSV / JSON / XML / HTML / MD — text editing.
- DOC / XLS / PPT — detected and handed to a compatible installed editor, because these legacy binary formats require a dedicated binary Office engine.

## Privacy
The app does not request broad storage permission. Files are opened via the Android system picker. No analytics, ads, cloud upload, account, or network permission is included.

## Build in Android Studio
1. Open the `OfficeBox` folder.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Debug APK: `app/build/outputs/apk/debug/app-debug.apk`.

Requirements: Android Studio with Android SDK 35, JDK 17+.

## GitHub Actions build
The repository includes `.github/workflows/build-apk.yml`. Push the folder to a GitHub repository and run the `Build APK` workflow; the APK is uploaded as a workflow artifact.

## Important scope note
This is a compact, dependency-free editor, not a replacement for Microsoft Office/LibreOffice. Full fidelity editing of advanced Word layout, complex Excel workbooks, PowerPoint object editing and arbitrary PDF text/object editing requires integrating a large Office engine such as ONLYOFFICE/Collabora or a commercial document SDK.
