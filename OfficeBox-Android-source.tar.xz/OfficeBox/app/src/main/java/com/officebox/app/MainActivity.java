package com.officebox.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int OPEN_FILE = 1001;
    private LinearLayout recentBox;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        if (Intent.ACTION_VIEW.equals(getIntent().getAction()) && getIntent().getData() != null) {
            openDocument(getIntent().getData());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        refreshRecent();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(26));
        root.setBackgroundColor(Color.rgb(248, 250, 252));
        scroll.addView(root);

        TextView title = text("OfficeBox", 30, true);
        root.addView(title);
        TextView sub = text("Документы, таблицы, презентации и PDF в одном приложении", 15, false);
        sub.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams sp = lp(-1, -2); sp.bottomMargin = dp(22);
        root.addView(sub, sp);

        Button open = button("Открыть файл");
        open.setOnClickListener(v -> pickFile());
        root.addView(open, lp(-1, dp(56)));

        TextView formats = text("Поддержка: DOCX, XLSX, PPTX, PDF, ODT/ODS/ODP, RTF, TXT, CSV, JSON, XML, HTML.\nСтарые DOC/XLS/PPT можно передать установленному системному редактору.", 14, false);
        formats.setTextColor(Color.rgb(71,85,105));
        LinearLayout.LayoutParams fp = lp(-1,-2); fp.topMargin=dp(18); fp.bottomMargin=dp(26);
        root.addView(formats, fp);

        TextView recent = text("Недавние", 20, true);
        root.addView(recent);
        recentBox = new LinearLayout(this);
        recentBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams rp = lp(-1,-2); rp.topMargin=dp(8);
        root.addView(recentBox, rp);
        setContentView(scroll);
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, OPEN_FILE);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == OPEN_FILE && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            } catch (Exception ignored) {}
            remember(uri);
            openDocument(uri);
        }
    }

    private void openDocument(Uri uri) {
        Intent i = new Intent(this, DocumentActivity.class);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivity(i);
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {}
        return uri.getLastPathSegment() == null ? "Документ" : uri.getLastPathSegment();
    }

    private void remember(Uri uri) {
        SharedPreferences p = getSharedPreferences("recent", MODE_PRIVATE);
        Set<String> old = p.getStringSet("uris", new LinkedHashSet<>());
        LinkedHashSet<String> next = new LinkedHashSet<>();
        next.add(uri.toString());
        next.addAll(old);
        while (next.size() > 8) {
            String last = null; for (String s : next) last = s; if (last != null) next.remove(last);
        }
        p.edit().putStringSet("uris", next).apply();
    }

    private void refreshRecent() {
        if (recentBox == null) return;
        recentBox.removeAllViews();
        Set<String> set = getSharedPreferences("recent", MODE_PRIVATE).getStringSet("uris", new LinkedHashSet<>());
        if (set.isEmpty()) {
            TextView empty = text("Здесь появятся недавно открытые файлы.", 14, false);
            empty.setTextColor(Color.GRAY);
            recentBox.addView(empty);
            return;
        }
        for (String s : set) {
            Uri uri = Uri.parse(s);
            TextView item = text("▣  " + displayName(uri), 16, false);
            item.setPadding(dp(14), dp(14), dp(14), dp(14));
            item.setBackgroundColor(Color.WHITE);
            item.setOnClickListener(v -> {
                try { openDocument(uri); } catch (Exception e) { Toast.makeText(this, "Не удалось открыть файл", Toast.LENGTH_SHORT).show(); }
            });
            LinearLayout.LayoutParams p = lp(-1,-2); p.bottomMargin=dp(8);
            recentBox.addView(item,p);
        }
    }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(15,23,42));
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(16); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackgroundResource(com.officebox.app.R.drawable.rounded_button); return b; }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }
    private int dp(int v){ return Math.round(v*getResources().getDisplayMetrics().density); }
}
