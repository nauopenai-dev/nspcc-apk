package com.officebox.app;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;

import java.io.*;
import java.util.*;

public class DocumentActivity extends Activity {
    private static final int SAVE_AS=4001;
    private Uri uri;
    private String name, ext;
    private byte[] original;
    private EditText editor;
    private LinearLayout root;
    private PdfRenderer pdf;
    private ParcelFileDescriptor pdfFd;
    private ImageView pdfImage;
    private int pageIndex=0;
    private final Map<Integer,String> pdfNotes=new HashMap<>();
    private boolean pendingPdfSave=false;

    @Override public void onCreate(Bundle b){super.onCreate(b); uri=getIntent().getData(); name=displayName(uri); ext=OfficeCodec.ext(name); buildShell(); load();}
    @Override protected void onDestroy(){super.onDestroy(); closePdf();}

    private void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(248,250,252));
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),dp(8),dp(8),dp(8));
        Button back=small("‹"); back.setOnClickListener(v->finish()); bar.addView(back,new LinearLayout.LayoutParams(dp(52),dp(48)));
        TextView title=new TextView(this); title.setText(name); title.setTextSize(17); title.setTextColor(Color.rgb(15,23,42)); title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setMaxLines(1); title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        bar.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        root.addView(bar); setContentView(root);
    }

    private void load(){
        try {
            if(ext.equals("pdf")){showPdf(); return;}
            if(ext.equals("doc")||ext.equals("xls")||ext.equals("ppt")){showLegacy(); return;}
            original=OfficeCodec.readAll(this,uri); String text=OfficeCodec.extract(ext,original); showEditor(text);
        } catch(Exception e){showError("Не удалось открыть файл: "+e.getMessage());}
    }

    private void showEditor(String text){
        LinearLayout tools=new LinearLayout(this); tools.setPadding(dp(10),dp(6),dp(10),dp(6)); tools.setGravity(Gravity.CENTER_VERTICAL);
        TextView kind=new TextView(this); kind.setText(ext.toUpperCase(Locale.ROOT)+" • встроенный редактор"); kind.setTextSize(13); kind.setTextColor(Color.DKGRAY); tools.addView(kind,new LinearLayout.LayoutParams(0,-2,1));
        Button save=small("Сохранить как"); save.setOnClickListener(v->chooseSave(false)); tools.addView(save); root.addView(tools);
        editor=new EditText(this); editor.setText(text); editor.setTextSize(ext.equals("xlsx")?14:16); editor.setTextColor(Color.rgb(15,23,42)); editor.setBackgroundColor(Color.WHITE); editor.setGravity(Gravity.TOP|Gravity.START); editor.setPadding(dp(16),dp(16),dp(16),dp(80)); editor.setHorizontallyScrolling(ext.equals("xlsx"));
        if(ext.equals("xlsx")||ext.equals("csv")) editor.setTypeface(Typeface.MONOSPACE);
        root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
    }

    private void showLegacy(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(24),dp(24),dp(24),dp(24));
        TextView t=new TextView(this); t.setText("Формат ."+ext.toUpperCase(Locale.ROOT)+" — старый бинарный формат Microsoft Office. OfficeBox распознал файл, но для безопасного редактирования без повреждения передаст его установленному офисному приложению.\n\nДля встроенного редактирования сохраните документ как DOCX / XLSX / PPTX."); t.setTextSize(16); t.setTextColor(Color.rgb(30,41,59)); box.addView(t);
        Button b=small("Открыть во внешнем редакторе"); b.setOnClickListener(v->externalEdit()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56));p.topMargin=dp(20);box.addView(b,p);root.addView(box);
    }

    private void externalEdit(){try{Intent i=new Intent(Intent.ACTION_EDIT);i.setDataAndType(uri,getContentResolver().getType(uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);startActivity(Intent.createChooser(i,"Выберите редактор"));}catch(Exception e){Toast.makeText(this,"На устройстве нет подходящего редактора",Toast.LENGTH_LONG).show();}}

    private void showPdf() throws Exception {
        pdfFd=getContentResolver().openFileDescriptor(uri,"r"); if(pdfFd==null)throw new IOException("PDF недоступен"); pdf=new PdfRenderer(pdfFd);
        LinearLayout tools=new LinearLayout(this); tools.setGravity(Gravity.CENTER); tools.setPadding(dp(8),dp(6),dp(8),dp(6));
        Button prev=small("◀"); Button next=small("▶"); Button note=small("Текст"); Button save=small("Сохранить PDF");
        prev.setOnClickListener(v->{if(pageIndex>0){pageIndex--;renderPdf();}}); next.setOnClickListener(v->{if(pageIndex<pdf.getPageCount()-1){pageIndex++;renderPdf();}}); note.setOnClickListener(v->editPdfNote()); save.setOnClickListener(v->chooseSave(true));
        tools.addView(prev); tools.addView(next); tools.addView(note); tools.addView(save); root.addView(tools);
        ScrollView sv=new ScrollView(this); pdfImage=new ImageView(this); pdfImage.setAdjustViewBounds(true); pdfImage.setBackgroundColor(Color.LTGRAY); sv.addView(pdfImage); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); renderPdf();
    }

    private void renderPdf(){
        if(pdf==null)return; try(PdfRenderer.Page p=pdf.openPage(pageIndex)){int w=Math.min(1600,Math.max(900,p.getWidth()*2));int h=Math.round((float)w*p.getHeight()/p.getWidth());Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);String n=pdfNotes.get(pageIndex);if(n!=null&&!n.isEmpty()){Canvas c=new Canvas(b);Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.rgb(220,38,38));paint.setTextSize(Math.max(28,w/35f));paint.setTypeface(Typeface.DEFAULT_BOLD);drawWrapped(c,n,paint,40,60,w-80);}pdfImage.setImageBitmap(b);setTitle(""+(pageIndex+1)+" / "+pdf.getPageCount());}catch(Exception e){Toast.makeText(this,"Ошибка страницы PDF",Toast.LENGTH_SHORT).show();}
    }

    private void editPdfNote(){final EditText e=new EditText(this);e.setHint("Текст на текущей странице");e.setText(pdfNotes.getOrDefault(pageIndex,""));new AlertDialog.Builder(this).setTitle("Добавить текст").setView(e).setPositiveButton("Готово",(d,w)->{pdfNotes.put(pageIndex,e.getText().toString());renderPdf();}).setNegativeButton("Отмена",null).show();}

    private void chooseSave(boolean pdfMode){pendingPdfSave=pdfMode; Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(pdfMode?"application/pdf":"*/*");String base=name;int dot=base.lastIndexOf('.');if(dot>0)base=base.substring(0,dot)+"_edited"+base.substring(dot);else base+="_edited";i.putExtra(Intent.EXTRA_TITLE,base);startActivityForResult(i,SAVE_AS);}

    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==SAVE_AS&&res==RESULT_OK&&data!=null&&data.getData()!=null){Uri out=data.getData();try{if(pendingPdfSave)savePdf(out);else saveOffice(out);Toast.makeText(this,"Файл сохранён",Toast.LENGTH_LONG).show();}catch(Exception e){new AlertDialog.Builder(this).setTitle("Не удалось сохранить").setMessage(e.toString()).setPositiveButton("OK",null).show();}}}

    private void saveOffice(Uri out) throws Exception {byte[] bytes=OfficeCodec.save(ext,original,editor.getText().toString());try(OutputStream os=getContentResolver().openOutputStream(out,"w")){if(os==null)throw new IOException();os.write(bytes);}}

    private void savePdf(Uri out) throws Exception {
        PdfDocument doc=new PdfDocument();
        for(int i=0;i<pdf.getPageCount();i++){
            try(PdfRenderer.Page p=pdf.openPage(i)){
                int w=Math.min(1600,Math.max(900,p.getWidth()*2));int h=Math.round((float)w*p.getHeight()/p.getWidth());Bitmap b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);b.eraseColor(Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(w,h,i+1).create();PdfDocument.Page page=doc.startPage(info);page.getCanvas().drawBitmap(b,0,0,null);
                String n=pdfNotes.get(i);if(n!=null&&!n.isEmpty()){Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);paint.setColor(Color.rgb(220,38,38));paint.setTextSize(Math.max(28,w/35f));paint.setTypeface(Typeface.DEFAULT_BOLD);drawWrapped(page.getCanvas(),n,paint,40,60,w-80);}doc.finishPage(page);b.recycle();
            }
        }
        try(OutputStream os=getContentResolver().openOutputStream(out,"w")){if(os==null)throw new IOException();doc.writeTo(os);}finally{doc.close();}
    }

    private void drawWrapped(Canvas c,String s,Paint p,float x,float y,float width){float line=p.getTextSize()*1.3f;for(String paragraph:s.split("\\R")){StringBuilder cur=new StringBuilder();for(String word:paragraph.split(" ")){String test=cur.length()==0?word:cur+" "+word;if(p.measureText(test)>width&&cur.length()>0){c.drawText(cur.toString(),x,y,p);y+=line;cur.setLength(0);cur.append(word);}else{if(cur.length()>0)cur.append(' ');cur.append(word);}}c.drawText(cur.toString(),x,y,p);y+=line;}}
    private void closePdf(){try{if(pdf!=null)pdf.close();}catch(Exception ignored){}try{if(pdfFd!=null)pdfFd.close();}catch(Exception ignored){}}
    private void showError(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(16);t.setTextColor(Color.RED);t.setPadding(dp(24),dp(24),dp(24),dp(24));root.addView(t);}
    private String displayName(Uri u){try(Cursor c=getContentResolver().query(u,null,null,null,null)){if(c!=null&&c.moveToFirst()){int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(i>=0)return c.getString(i);}}catch(Exception ignored){}return "Документ";}
    private Button small(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(13);return b;}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
