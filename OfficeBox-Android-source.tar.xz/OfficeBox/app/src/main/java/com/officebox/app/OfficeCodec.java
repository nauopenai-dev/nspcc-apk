package com.officebox.app;

import android.content.Context;
import android.net.Uri;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.xml.parsers.DocumentBuilderFactory;

public final class OfficeCodec {
    private OfficeCodec() {}

    public static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i+1).toLowerCase(Locale.ROOT);
    }

    public static byte[] readAll(Context c, Uri uri) throws IOException {
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new FileNotFoundException();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[8192]; int n;
            while ((n=in.read(b))>0) out.write(b,0,n);
            return out.toByteArray();
        }
    }

    public static String extract(String extension, byte[] data) throws Exception {
        switch (extension) {
            case "docx": return extractDocx(data);
            case "xlsx": return extractXlsx(data);
            case "pptx": return extractPptx(data);
            case "odt": case "ods": case "odp": return extractOpenDocument(data);
            case "rtf": return extractRtf(new String(data, StandardCharsets.UTF_8));
            default: return new String(data, StandardCharsets.UTF_8);
        }
    }

    public static byte[] save(String extension, byte[] original, String edited) throws Exception {
        switch (extension) {
            case "docx": return patchDocx(original, edited);
            case "xlsx": return patchXlsx(original, edited);
            case "pptx": return patchPptx(original, edited);
            case "odt": case "ods": case "odp": return patchOpenDocument(original, edited);
            case "rtf": return toRtf(edited).getBytes(StandardCharsets.UTF_8);
            default: return edited.getBytes(StandardCharsets.UTF_8);
        }
    }

    private static Map<String, byte[]> unzip(byte[] data) throws IOException {
        LinkedHashMap<String, byte[]> map = new LinkedHashMap<>();
        try (ZipInputStream z = new ZipInputStream(new ByteArrayInputStream(data))) {
            ZipEntry e;
            while ((e=z.getNextEntry()) != null) {
                ByteArrayOutputStream o = new ByteArrayOutputStream();
                byte[] b = new byte[8192]; int n;
                while ((n=z.read(b))>0) o.write(b,0,n);
                map.put(e.getName(), o.toByteArray());
            }
        }
        return map;
    }

    private static byte[] rezip(Map<String, byte[]> map) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try (ZipOutputStream z = new ZipOutputStream(out)) {
            for (Map.Entry<String, byte[]> x : map.entrySet()) {
                z.putNextEntry(new ZipEntry(x.getKey())); z.write(x.getValue()); z.closeEntry();
            }
        }
        return out.toByteArray();
    }

    private static String extractDocx(byte[] data) throws Exception {
        Map<String, byte[]> z = unzip(data);
        String xml = str(z.get("word/document.xml"));
        if (xml == null) return "";
        List<String> pars = new ArrayList<>();
        Matcher pm = Pattern.compile("<w:p\\b[^>]*>(.*?)</w:p>", Pattern.DOTALL).matcher(xml);
        while (pm.find()) pars.add(textNodes(pm.group(1), "w:t"));
        return join(pars, "\n");
    }

    private static byte[] patchDocx(byte[] original, String edited) throws Exception {
        Map<String, byte[]> z = unzip(original);
        String xml = str(z.get("word/document.xml"));
        if (xml == null) throw new IOException("Некорректный DOCX");
        String[] lines = edited.split("\\R", -1);
        Matcher pm = Pattern.compile("<w:p\\b[^>]*>.*?</w:p>", Pattern.DOTALL).matcher(xml);
        StringBuffer sb = new StringBuffer(); int i=0;
        while (pm.find()) {
            String p = pm.group();
            if (i < lines.length) p = replaceTaggedTexts(p, "w:t", lines[i]);
            else p = replaceTaggedTexts(p, "w:t", "");
            pm.appendReplacement(sb, Matcher.quoteReplacement(p)); i++;
        }
        pm.appendTail(sb);
        if (i < lines.length) {
            StringBuilder extra = new StringBuilder();
            for (; i<lines.length; i++) extra.append("<w:p><w:r><w:t xml:space=\"preserve\">").append(esc(lines[i])).append("</w:t></w:r></w:p>");
            int pos = sb.lastIndexOf("</w:body>");
            if (pos >= 0) sb.insert(pos, extra);
        }
        z.put("word/document.xml", sb.toString().getBytes(StandardCharsets.UTF_8));
        return rezip(z);
    }

    private static String extractXlsx(byte[] data) throws Exception {
        Map<String, byte[]> z = unzip(data);
        List<String> shared = new ArrayList<>();
        String sst = str(z.get("xl/sharedStrings.xml"));
        if (sst != null) {
            Matcher si = Pattern.compile("<si\\b[^>]*>(.*?)</si>", Pattern.DOTALL).matcher(sst);
            while (si.find()) shared.add(textNodes(si.group(1), "t"));
        }
        String sheet = str(z.get("xl/worksheets/sheet1.xml"));
        if (sheet == null) return "";
        TreeMap<Integer, TreeMap<Integer,String>> grid = new TreeMap<>();
        Matcher cm = Pattern.compile("<c\\b([^>]*)>(.*?)</c>", Pattern.DOTALL).matcher(sheet);
        while (cm.find()) {
            String attrs=cm.group(1), body=cm.group(2);
            String ref=attr(attrs,"r"); if (ref==null) continue;
            int row=rowOf(ref), col=colOf(ref);
            String type=attr(attrs,"t"); String value="";
            Matcher vm=Pattern.compile("<v>(.*?)</v>",Pattern.DOTALL).matcher(body);
            if ("inlineStr".equals(type)) value=textNodes(body,"t");
            else if (vm.find()) { value=unesc(vm.group(1)); if ("s".equals(type)) { try { value=shared.get(Integer.parseInt(value)); } catch(Exception ignored){} } }
            grid.computeIfAbsent(row,k->new TreeMap<>()).put(col,value);
        }
        int maxCol=0; for (TreeMap<Integer,String> r:grid.values()) if(!r.isEmpty()) maxCol=Math.max(maxCol,r.lastKey());
        StringBuilder out=new StringBuilder(); int maxRow=grid.isEmpty()?0:grid.lastKey();
        for(int r=1;r<=maxRow;r++) { TreeMap<Integer,String> row=grid.get(r); for(int c=1;c<=maxCol;c++){ if(c>1) out.append('\t'); if(row!=null) out.append(row.getOrDefault(c,"")); } if(r<maxRow) out.append('\n'); }
        return out.toString();
    }

    private static byte[] patchXlsx(byte[] original, String edited) throws Exception {
        Map<String, byte[]> z=unzip(original);
        String[] rows=edited.split("\\R",-1);
        StringBuilder x=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        for(int r=0;r<rows.length;r++) {
            x.append("<row r=\"").append(r+1).append("\">");
            String[] cells=rows[r].split("\\t",-1);
            for(int c=0;c<cells.length;c++) {
                String ref=colName(c+1)+(r+1), v=cells[c]; if(v.isEmpty()) continue;
                if(v.matches("[-+]?\\d+(\\.\\d+)?")) x.append("<c r=\"").append(ref).append("\"><v>").append(esc(v)).append("</v></c>");
                else x.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(v)).append("</t></is></c>");
            }
            x.append("</row>");
        }
        x.append("</sheetData></worksheet>");
        if (!z.containsKey("xl/worksheets/sheet1.xml")) throw new IOException("Некорректный XLSX");
        z.put("xl/worksheets/sheet1.xml",x.toString().getBytes(StandardCharsets.UTF_8));
        return rezip(z);
    }

    private static String extractPptx(byte[] data) throws Exception {
        Map<String, byte[]> z=unzip(data);
        List<String> names=new ArrayList<>();
        for(String n:z.keySet()) if(n.matches("ppt/slides/slide\\d+\\.xml")) names.add(n);
        names.sort(Comparator.comparingInt(OfficeCodec::slideNo));
        StringBuilder out=new StringBuilder(); int i=1;
        for(String n:names){ if(out.length()>0) out.append("\n\n"); out.append("=== Слайд ").append(i++).append(" ===\n"); String xml=str(z.get(n)); List<String> texts=allTagTexts(xml,"a:t"); out.append(join(texts,"\n")); }
        return out.toString();
    }

    private static byte[] patchPptx(byte[] original, String edited) throws Exception {
        Map<String, byte[]> z=unzip(original);
        List<String> names=new ArrayList<>(); for(String n:z.keySet()) if(n.matches("ppt/slides/slide\\d+\\.xml")) names.add(n);
        names.sort(Comparator.comparingInt(OfficeCodec::slideNo));
        String[] parts=edited.split("(?m)^=== Слайд \\d+ ===\\s*$",-1);
        for(int i=0;i<names.size();i++) {
            String body = i+1<parts.length ? parts[i+1].replaceFirst("^\\R","") : "";
            String[] lines=body.split("\\R",-1);
            String xml=str(z.get(names.get(i)));
            Matcher m=Pattern.compile("(<a:t\\b[^>]*>)(.*?)(</a:t>)",Pattern.DOTALL).matcher(xml);
            StringBuffer sb=new StringBuffer(); int k=0;
            while(m.find()) { String v=k<lines.length?lines[k++]:""; m.appendReplacement(sb,Matcher.quoteReplacement(m.group(1)+esc(v)+m.group(3))); }
            m.appendTail(sb);
            z.put(names.get(i),sb.toString().getBytes(StandardCharsets.UTF_8));
        }
        return rezip(z);
    }

    private static String extractOpenDocument(byte[] data) throws Exception {
        Map<String, byte[]> z=unzip(data); String xml=str(z.get("content.xml")); if(xml==null)return "";
        List<String> pars=allTagTextsRegex(xml,"(?:text:p|text:h)");
        return join(pars,"\n");
    }

    private static byte[] patchOpenDocument(byte[] original,String edited) throws Exception {
        Map<String, byte[]> z=unzip(original); String xml=str(z.get("content.xml")); if(xml==null)throw new IOException("Некорректный OpenDocument");
        String[] lines=edited.split("\\R",-1);
        Pattern p=Pattern.compile("(<(?:text:p|text:h)\\b[^>]*>)(.*?)(</(?:text:p|text:h)>)",Pattern.DOTALL);
        Matcher m=p.matcher(xml); StringBuffer sb=new StringBuffer(); int i=0;
        while(m.find()){String v=i<lines.length?lines[i++]:""; m.appendReplacement(sb,Matcher.quoteReplacement(m.group(1)+esc(v)+m.group(3)));} m.appendTail(sb);
        z.put("content.xml",sb.toString().getBytes(StandardCharsets.UTF_8)); return rezip(z);
    }

    private static String extractRtf(String rtf) {
        return rtf.replaceAll("\\\\'[0-9a-fA-F]{2}","")
                .replaceAll("\\\\[a-zA-Z]+-?\\d* ?","")
                .replace("{","").replace("}","").replace("\\\\","\\");
    }
    private static String toRtf(String text) {
        StringBuilder b=new StringBuilder("{\\rtf1\\ansi\\deff0\n");
        for(char ch:text.toCharArray()) {
            if(ch=='\\'||ch=='{'||ch=='}') b.append('\\').append(ch);
            else if(ch=='\n') b.append("\\par\n");
            else if(ch<128) b.append(ch);
            else b.append("\\u").append((int)ch).append('?');
        }
        return b.append('}').toString();
    }

    private static String replaceTaggedTexts(String xml,String tag,String text){
        Matcher m=Pattern.compile("(<"+Pattern.quote(tag)+"\\b[^>]*>)(.*?)(</"+Pattern.quote(tag)+">)",Pattern.DOTALL).matcher(xml);
        StringBuffer sb=new StringBuffer(); boolean first=true;
        while(m.find()){String v=first?text:""; first=false; m.appendReplacement(sb,Matcher.quoteReplacement(m.group(1)+esc(v)+m.group(3)));} m.appendTail(sb);
        if(first){int p=xml.indexOf('>'); if(p>=0)return xml.substring(0,p+1)+"<w:r><w:t xml:space=\"preserve\">"+esc(text)+"</w:t></w:r>"+xml.substring(p+1);} return sb.toString();
    }
    private static List<String> allTagTexts(String xml,String tag){List<String> a=new ArrayList<>(); Matcher m=Pattern.compile("<"+Pattern.quote(tag)+"\\b[^>]*>(.*?)</"+Pattern.quote(tag)+">",Pattern.DOTALL).matcher(xml); while(m.find())a.add(unesc(stripTags(m.group(1)))); return a;}
    private static List<String> allTagTextsRegex(String xml,String tags){List<String>a=new ArrayList<>();Matcher m=Pattern.compile("<"+tags+"\\b[^>]*>(.*?)</"+tags+">",Pattern.DOTALL).matcher(xml);while(m.find())a.add(unesc(stripTags(m.group(1))));return a;}
    private static String textNodes(String xml,String tag){return join(allTagTexts(xml,tag),"");}
    private static String stripTags(String s){return s.replaceAll("<[^>]+>","");}
    private static String str(byte[] b){return b==null?null:new String(b,StandardCharsets.UTF_8);}
    private static String attr(String attrs,String n){Matcher m=Pattern.compile("\\b"+Pattern.quote(n)+"=\"([^\"]*)\"").matcher(attrs);return m.find()?m.group(1):null;}
    private static int rowOf(String r){Matcher m=Pattern.compile("(\\d+)$").matcher(r);return m.find()?Integer.parseInt(m.group(1)):1;}
    private static int colOf(String r){String s=r.replaceAll("[^A-Za-z]","").toUpperCase(Locale.ROOT);int n=0;for(char c:s.toCharArray())n=n*26+(c-'A'+1);return Math.max(n,1);}
    private static String colName(int n){StringBuilder s=new StringBuilder();while(n>0){n--;s.append((char)('A'+n%26));n/=26;}return s.reverse().toString();}
    private static int slideNo(String s){Matcher m=Pattern.compile("slide(\\d+)\\.xml").matcher(s);return m.find()?Integer.parseInt(m.group(1)):0;}
    private static String join(Collection<String> x,String d){StringBuilder b=new StringBuilder();boolean f=true;for(String s:x){if(!f)b.append(d);b.append(s);f=false;}return b.toString();}
    private static String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private static String unesc(String s){return s.replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&apos;","'").replace("&amp;","&");}
}
